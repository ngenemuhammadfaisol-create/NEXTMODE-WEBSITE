
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { MessageCircle, Send } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ColorSwatch from '@/components/ColorSwatch.jsx';
import SizeSelector from '@/components/SizeSelector.jsx';
import MaterialSelector from '@/components/MaterialSelector.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';

const formSchema = z.object({
  boothName: z.string().min(2, 'Nama booth minimal 2 karakter'),
  color: z.string().min(1, 'Silakan pilih warna'),
  size: z.string().min(1, 'Silakan pilih ukuran'),
  material: z.string().min(1, 'Silakan pilih material'),
  designPreferences: z.string().min(10, 'Berikan preferensi desain (minimal 10 karakter)'),
  quantity: z.string().min(1, 'Silakan masukkan jumlah'),
  customerName: z.string().min(2, 'Nama minimal 2 karakter'),
  customerEmail: z.string().email('Silakan masukkan alamat email yang valid'),
  customerPhone: z.string().min(10, 'Silakan masukkan nomor telepon yang valid')
});

const colors = [
  { name: "Cokelat Kayu", hex: "#8B4513" },
  { name: "Hitam Arang", hex: "#2C3E50" },
  { name: "Putih", hex: "#FFFFFF" },
  { name: "Ek Alami", hex: "#D4A574" },
  { name: "Abu-abu", hex: "#708090" },
  { name: "Merah", hex: "#DC143C" }
];

const CustomOrderPage = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedMaterial, setSelectedMaterial] = useState('');
  
  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      boothName: '',
      color: '',
      size: '',
      material: '',
      designPreferences: '',
      quantity: '1',
      customerName: '',
      customerEmail: '',
      customerPhone: ''
    }
  });
  
  const onSubmit = async (data) => {
    setIsSubmitting(true);
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const orderData = {
      ...data,
      timestamp: new Date().toISOString()
    };
    
    localStorage.setItem('customOrder', JSON.stringify(orderData));
    
    console.log('Pesanan custom dikirim:', orderData);
    
    toast.success('Pesanan berhasil disimpan');
    
    setIsSubmitting(false);
  };
  
  const handleWhatsAppOrder = () => {
    const values = form.getValues();
    const message = `Halo, saya ingin memesan booth custom:\n\nNama Booth: ${values.boothName}\nWarna: ${selectedColor}\nUkuran: ${selectedSize}\nMaterial: ${selectedMaterial}\nJumlah: ${values.quantity}\n\nPreferensi Desain:\n${values.designPreferences}\n\nKontak:\nNama: ${values.customerName}\nEmail: ${values.customerEmail}\nTelepon: ${values.customerPhone}`;
    
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/6289632611030?text=${encodedMessage}`, '_blank');
  };
  
  return (
    <>
      <Helmet>
        <title>Pesan Custom - NEXTMODE Portable Booths</title>
        <meta name="description" content="Desain booth portable sempurna Anda. Kustomisasi warna, material, ukuran, dan tata letak agar sesuai dengan merek dan kebutuhan bisnis Anda." />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1">
          <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h1 className="text-4xl md:text-5xl font-bold mb-4">Desain Booth Custom Anda</h1>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Ceritakan visi Anda, dan kami akan membangun booth yang mewujudkannya
                </p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="bg-card p-8 rounded-2xl border border-border"
              >
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                    <FormField
                      control={form.control}
                      name="boothName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nama Booth / Merek</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="misal: Kopi Pesisir, Pasar Urban"
                              {...field}
                              className="text-foreground"
                            />
                          </FormControl>
                          <FormDescription>
                            Apa nama booth Anda?
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="color"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pilihan Warna</FormLabel>
                          <FormControl>
                            <div className="flex flex-wrap gap-4">
                              {colors.map((color) => (
                                <ColorSwatch
                                  key={color.name}
                                  color={color.hex}
                                  name={color.name}
                                  selected={selectedColor === color.name}
                                  onClick={() => {
                                    setSelectedColor(color.name);
                                    field.onChange(color.name);
                                  }}
                                />
                              ))}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="size"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pilihan Ukuran</FormLabel>
                          <FormControl>
                            <SizeSelector
                              selected={selectedSize}
                              onChange={(size) => {
                                setSelectedSize(size);
                                field.onChange(size);
                              }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="material"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pilihan Material</FormLabel>
                          <FormControl>
                            <MaterialSelector
                              selected={selectedMaterial}
                              onChange={(material) => {
                                setSelectedMaterial(material);
                                field.onChange(material);
                              }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="designPreferences"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Permintaan Khusus</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Jelaskan desain booth ideal Anda, fitur khusus, kebutuhan branding, atau kebutuhan spesifik lainnya..."
                              rows={6}
                              {...field}
                              className="text-foreground resize-none"
                            />
                          </FormControl>
                          <FormDescription>
                            Ceritakan tentang visi Anda, persyaratan khusus, atau fitur yang Anda butuhkan
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Jumlah</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="1"
                              placeholder="1"
                              {...field}
                              className="text-foreground"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="border-t border-border pt-8">
                      <h3 className="text-xl font-semibold mb-6">Informasi Anda</h3>
                      
                      <div className="space-y-6">
                        <FormField
                          control={form.control}
                          name="customerName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nama Lengkap</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Nama Anda"
                                  {...field}
                                  className="text-foreground"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="customerEmail"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input
                                  type="email"
                                  placeholder="email.anda@contoh.com"
                                  {...field}
                                  className="text-foreground"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="customerPhone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nomor Telepon</FormLabel>
                              <FormControl>
                                <Input
                                  type="tel"
                                  placeholder="08123456789"
                                  {...field}
                                  className="text-foreground"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row gap-4">
                      <Button
                        type="submit"
                        className="flex-1 bg-secondary text-secondary-foreground hover:bg-secondary/90"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          'Menyimpan pesanan...'
                        ) : (
                          <>
                            Kirim Pesanan
                            <Send className="ml-2 w-4 h-4" />
                          </>
                        )}
                      </Button>
                      
                      <Button
                        type="button"
                        variant="outline"
                        className="flex-1"
                        onClick={handleWhatsAppOrder}
                      >
                        <MessageCircle className="mr-2 w-4 h-4" />
                        Kirim via WhatsApp
                      </Button>
                    </div>
                  </form>
                </Form>
              </motion.div>
            </div>
          </section>
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default CustomOrderPage;
