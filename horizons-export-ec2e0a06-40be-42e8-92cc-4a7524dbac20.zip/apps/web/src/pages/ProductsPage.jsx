
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ProductCard from '@/components/ProductCard.jsx';
import { Button } from '@/components/ui/button';

export const allProducts = [
  {
    id: 1,
    name: "DAPOER KLEON",
    category: "Makanan",
    image: "https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/c31607222d5885814fc9ddb527ad6d3a.jpg",
    description: "Booth makanan kompak dengan desain modern dan setup peralatan lengkap. Cocok untuk berbagai jenis makanan cepat saji.",
    price: "Mulai dari Rp 15.000.000"
  },
  {
    id: 2,
    name: "Sweets Bites",
    category: "Makanan Ringan",
    image: "https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/7010411256ad62c81d6224cf181a7a27.jpg",
    description: "Booth serbaguna dengan rak yang dapat disesuaikan dan opsi tampilan menarik. Ideal untuk camilan dan makanan manis.",
    price: "Mulai dari Rp 12.500.000"
  },
  {
    id: 3,
    name: "Naura Sunrise",
    category: "Minuman",
    image: "https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/c776d9015f933964b856d7b1ddb6de2c.jpg",
    description: "Kios minuman segar dengan pendingin dan meja persiapan. Desain cerah yang menarik perhatian pelanggan.",
    price: "Mulai dari Rp 18.000.000"
  },
  {
    id: 4,
    name: "Satebus",
    category: "Makanan",
    image: "https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/79172f643978a7d82555c58d0c18883c.jpg",
    description: "Gerobak makanan mobile dengan peralatan memasak bawaan dan penyimpanan. Sempurna untuk pedagang kaki lima.",
    price: "Mulai dari Rp 22.000.000"
  },
  {
    id: 5,
    name: "TWOEIC2",
    category: "Ritel",
    image: "https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/77053e13a51fdf5505f81dd8eaddba56.jpg",
    description: "Stan ritel elegan dengan ruang pajangan yang luas. Cocok untuk pameran dan penjualan produk gaya hidup.",
    price: "Mulai dari Rp 16.500.000"
  }
];

const categories = ['Semua', 'Makanan', 'Minuman', 'Makanan Ringan', 'Ritel'];

const ProductsPage = () => {
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  
  const filteredProducts = selectedCategory === 'Semua'
    ? allProducts
    : allProducts.filter(product => product.category === selectedCategory);
  
  return (
    <>
      <Helmet>
        <title>Produk Unggulan - NEXTMODE Portable Booths</title>
        <meta name="description" content="Jelajahi koleksi booth portable kami yang dapat dikustomisasi untuk makanan, minuman, ritel, dan aplikasi kustom. Temukan booth yang sempurna untuk bisnis Anda." />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1">
          <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h1 className="text-4xl md:text-5xl font-bold mb-4">Produk Unggulan</h1>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Jelajahi rangkaian booth portable kami yang dirancang untuk berbagai kebutuhan bisnis
                </p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="flex flex-wrap justify-center gap-3 mb-12"
              >
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category)}
                    className={selectedCategory === category ? "bg-primary text-primary-foreground" : ""}
                  >
                    {category}
                  </Button>
                ))}
              </motion.div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProducts.map((product, index) => (
                  <ProductCard key={product.id} product={product} index={index} />
                ))}
              </div>
              
              {filteredProducts.length === 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-20"
                >
                  <p className="text-lg text-muted-foreground">Tidak ada produk yang ditemukan dalam kategori ini</p>
                </motion.div>
              )}
            </div>
          </section>
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default ProductsPage;
