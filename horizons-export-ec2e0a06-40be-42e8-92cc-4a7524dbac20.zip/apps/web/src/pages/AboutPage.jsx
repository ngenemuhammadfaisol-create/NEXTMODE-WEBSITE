
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle2, Users, Award, Sparkles } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const advantages = [
  {
    icon: CheckCircle2,
    title: "Portabel dan Fleksibel",
    description: "Pindahkan bisnis Anda ke mana pun peluang memanggil. Booth kami dirancang untuk transportasi mudah dan pengaturan cepat."
  },
  {
    icon: Sparkles,
    title: "Dapat Dikustomisasi Penuh",
    description: "Setiap booth dibangun sesuai spesifikasi Anda. Pilih warna, material, tata letak, dan branding yang sesuai dengan visi Anda."
  },
  {
    icon: Award,
    title: "Tahan Lama",
    description: "Material tahan cuaca dan konstruksi yang diperkuat memastikan booth Anda bertahan bertahun-tahun dalam penggunaan sehari-hari."
  },
  {
    icon: Users,
    title: "Dukungan Ahli",
    description: "Tim kami memandu Anda melalui desain, produksi, dan pengaturan untuk memastikan booth Anda melebihi ekspektasi."
  }
];

const testimonials = [
  {
    name: "Maya Chen",
    business: "Kopi Pesisir",
    quote: "Kami telah menjalankan kios kopi kami selama 8 bulan sekarang. Kualitas bangunannya luar biasa, dan pelanggan menyukai desain modernnya.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80"
  },
  {
    name: "Raj Patel",
    business: "Pasar Meridian",
    quote: "Opsi kustomisasi memungkinkan kami membuat persis apa yang kami butuhkan. Pengaturan memakan waktu 20 menit, dan kami siap berjualan.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80"
  },
  {
    name: "Lucia Torres",
    business: "Makanan Jalanan Ember",
    quote: "Investasi terbaik yang kami buat. Booth ini balik modal dalam 4 bulan, dan kami telah berekspansi ke dua lokasi lagi.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&q=80"
  }
];

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>Tentang Kami - NEXTMODE Portable Booths</title>
        <meta name="description" content="Pelajari tentang misi NEXTMODE untuk menyediakan booth portable berkualitas tinggi yang dapat dikustomisasi untuk bisnis. Temukan cerita, nilai, dan kisah sukses pelanggan kami." />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1">
          <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="max-w-3xl mx-auto text-center mb-16"
              >
                <img 
                  src="https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/7b04bfec5f84cc04be09609bf2d5dc88.jpg" 
                  alt="NEXTMODE Logo" 
                  className="h-16 w-auto object-contain rounded-md mx-auto mb-8 shadow-sm"
                />
                <h1 className="text-4xl md:text-5xl font-bold mb-6">Tentang NEXTMODE</h1>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Kami memulai NEXTMODE karena kami melihat terlalu banyak pengusaha berjuang dengan ruang ritel yang mahal dan tidak fleksibel. Misi kami sederhana: membangun booth portable yang memungkinkan Anda memulai dan mengembangkan bisnis dengan cara Anda sendiri.
                </p>
              </motion.div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                >
                  <h2 className="text-3xl font-bold mb-6">Cerita Kami</h2>
                  <div className="space-y-4 text-muted-foreground leading-relaxed">
                    <p>
                      Didirikan pada tahun 2023, NEXTMODE muncul dari pengamatan sederhana: ruang ritel tradisional menahan pengusaha kreatif. Sewa tinggi, sewa panjang, dan fleksibilitas terbatas membuatnya sulit untuk menguji ide dan mengembangkan bisnis.
                    </p>
                    <p>
                      Kami berangkat untuk mengubah itu. Dengan menggabungkan pengerjaan berkualitas dengan desain modular, kami menciptakan booth portable yang memberi Anda kebebasan untuk beroperasi di mana saja. Dari pasar petani hingga festival, dari sudut jalan hingga acara perusahaan, bisnis Anda dapat pergi ke mana pun pelanggan Anda berada.
                    </p>
                    <p>
                      Hari ini, kami telah membantu lebih dari 240 bisnis meluncurkan dan berekspansi dengan booth kustom kami. Masing-masing dibangun untuk bertahan lama, dirancang untuk menonjol, dan siap beradaptasi saat bisnis Anda tumbuh.
                    </p>
                  </div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                  className="relative"
                >
                  <img
                    src="https://images.unsplash.com/photo-1556761175-b413da4baf72?w=800&q=80"
                    alt="NEXTMODE workshop and team"
                    className="rounded-2xl shadow-xl"
                  />
                </motion.div>
              </div>
            </div>
          </section>
          
          <section className="py-20 bg-muted">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Mengapa Memilih Kami</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Kami fokus pada apa yang penting: kualitas, fleksibilitas, dan kesuksesan Anda
                </p>
              </motion.div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {advantages.map((advantage, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-card p-8 rounded-2xl"
                  >
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                      <advantage.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{advantage.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{advantage.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
          
          <section className="py-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Apa Kata Pelanggan Kami</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Kisah nyata dari bisnis yang menggunakan booth NEXTMODE
                </p>
              </motion.div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {testimonials.map((testimonial, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-card p-8 rounded-2xl border border-border"
                  >
                    <div className="flex items-center gap-4 mb-4">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-xl object-cover"
                      />
                      <div>
                        <p className="font-semibold text-foreground">{testimonial.name}</p>
                        <p className="text-sm text-muted-foreground">{testimonial.business}</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground leading-relaxed italic">
                      "{testimonial.quote}"
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default AboutPage;
