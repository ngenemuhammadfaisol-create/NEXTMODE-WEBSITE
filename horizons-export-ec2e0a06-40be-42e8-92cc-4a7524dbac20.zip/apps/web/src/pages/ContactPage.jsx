
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MessageCircle, Mail, MapPin, Send } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

const formSchema = z.object({
  name: z.string().min(2, 'Nama minimal 2 karakter'),
  email: z.string().email('Silakan masukkan alamat email yang valid'),
  message: z.string().min(10, 'Pesan minimal 10 karakter')
});

const ContactPage = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      email: '',
      message: ''
    }
  });
  
  const onSubmit = async (data) => {
    setIsSubmitting(true);
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    console.log('Form kontak dikirim:', data);
    
    toast.success('Pesan berhasil dikirim');
    form.reset();
    setIsSubmitting(false);
  };
  
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/6289632611030', '_blank');
  };
  
  return (
    <>
      <Helmet>
        <title>Kontak - NEXTMODE Portable Booths</title>
        <meta name="description" content="Hubungi NEXTMODE. Kirim pesan atau hubungi kami via WhatsApp untuk mendiskusikan proyek booth portable custom Anda." />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1">
          <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h1 className="text-4xl md:text-5xl font-bold mb-4">Hubungi Kami</h1>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Punya pertanyaan tentang booth kami? Siap untuk memulai pesanan custom Anda? Kami di sini untuk membantu.
                </p>
              </motion.div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                >
                  <div className="bg-card p-8 rounded-2xl border border-border">
                    <h2 className="text-2xl font-semibold mb-6">Kirim Pesan</h2>
                    
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nama</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Nama Anda"
                                  {...field}
                                  className="text-foreground"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input
                                  type="email"
                                  placeholder="email.anda@contoh.com"
                                  {...field}
                                  className="text-foreground"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="message"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Pesan</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Ceritakan tentang proyek Anda..."
                                  rows={6}
                                  {...field}
                                  className="text-foreground resize-none"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button
                          type="submit"
                          className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            'Mengirim...'
                          ) : (
                            <>
                              Kirim Pesan
                              <Send className="ml-2 w-4 h-4" />
                            </>
                          )}
                        </Button>
                      </form>
                    </Form>
                  </div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="space-y-6"
                >
                  <div className="bg-card p-8 rounded-2xl border border-border">
                    <h2 className="text-2xl font-semibold mb-6">Informasi Kontak</h2>
                    
                    <div className="space-y-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                          <MessageCircle className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground mb-1">WhatsApp</p>
                          <a
                            href="https://wa.me/6289632611030"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-primary transition-colors"
                          >
                            089632611030
                          </a>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                          <Mail className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground mb-1">Email</p>
                          <a
                            href="mailto:info@nextmode.com"
                            className="text-muted-foreground hover:text-primary transition-colors"
                          >
                            info@nextmode.com
                          </a>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                          <MapPin className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground mb-1">Lokasi</p>
                          <p className="text-muted-foreground">
                            Jakarta, Indonesia
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-secondary/10 p-8 rounded-2xl border border-secondary/20">
                    <h3 className="text-xl font-semibold mb-4 text-foreground">Respon Cepat via WhatsApp</h3>
                    <p className="text-muted-foreground mb-6 leading-relaxed">
                      Untuk respon tercepat, kirim pesan kepada kami di WhatsApp. Kami biasanya membalas dalam waktu 2 jam selama jam kerja.
                    </p>
                    <Button
                      onClick={handleWhatsAppClick}
                      className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90"
                    >
                      <MessageCircle className="mr-2 w-5 h-5" />
                      Hubungi via WhatsApp
                    </Button>
                  </div>
                </motion.div>
              </div>
            </div>
          </section>
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default ContactPage;
