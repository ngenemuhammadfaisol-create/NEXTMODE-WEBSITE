
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ZoomIn, ArrowRight } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { allProducts } from './ProductsPage.jsx';

const productData = {
  1: {
    ...allProducts[0],
    images: [
      allProducts[0].image,
      "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?w=1200&q=80",
      "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=1200&q=80"
    ],
    specs: {
      dimensions: "2.4m x 1.8m x 2.2m",
      material: "Plywood marine-grade dengan pelapis tahan cuaca",
      weight: "187 kg",
      setup: "20 menit dengan 2 orang"
    },
    colors: [
      { name: "Cokelat Kayu", hex: "#8B4513" },
      { name: "Hitam Arang", hex: "#2C3E50" },
      { name: "Putih", hex: "#FFFFFF" }
    ],
    materials: ["Kayu Premium", "Rangka Aluminium", "Panel Kanvas"]
  },
  2: {
    ...allProducts[1],
    images: [
      allProducts[1].image,
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&q=80",
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&q=80"
    ],
    specs: {
      dimensions: "3m x 2m x 2.5m",
      material: "Rangka baja berlapis bubuk dengan panel kayu",
      weight: "214 kg",
      setup: "25 menit dengan 2 orang"
    },
    colors: [
      { name: "Ek Alami", hex: "#D4A574" },
      { name: "Abu-abu", hex: "#708090" },
      { name: "Krem", hex: "#F5F5DC" }
    ],
    materials: ["Kayu Premium", "Rangka Aluminium"]
  },
  3: {
    ...allProducts[2],
    images: [
      allProducts[2].image,
      "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=1200&q=80",
      "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1200&q=80"
    ],
    specs: {
      dimensions: "2.5m x 2m x 2.3m",
      material: "Baja tahan karat dengan panel berinsulasi",
      weight: "250 kg",
      setup: "30 menit dengan 2 orang"
    },
    colors: [
      { name: "Merah", hex: "#DC143C" },
      { name: "Hitam", hex: "#1a1a1a" },
      { name: "Kuning", hex: "#FFD700" }
    ],
    materials: ["Kayu Premium", "Rangka Aluminium", "Panel Kanvas"]
  },
  4: {
    ...allProducts[3],
    images: [
      allProducts[3].image,
      "https://images.unsplash.com/photo-1565123409695-7b5ef63a2efb?w=1200&q=80",
      "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=1200&q=80"
    ],
    specs: {
      dimensions: "3.5m x 2m x 2.3m",
      material: "Baja tahan karat dengan panel berinsulasi",
      weight: "276 kg",
      setup: "30 menit dengan 2 orang"
    },
    colors: [
      { name: "Merah", hex: "#DC143C" },
      { name: "Hitam", hex: "#1a1a1a" },
      { name: "Kuning", hex: "#FFD700" }
    ],
    materials: ["Kayu Premium", "Rangka Aluminium", "Panel Kanvas"]
  },
  5: {
    ...allProducts[4],
    images: [
      allProducts[4].image,
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&q=80",
      "https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=1200&q=80"
    ],
    specs: {
      dimensions: "3m x 2m x 2.5m",
      material: "Rangka baja berlapis bubuk dengan panel kayu",
      weight: "214 kg",
      setup: "25 menit dengan 2 orang"
    },
    colors: [
      { name: "Ek Alami", hex: "#D4A574" },
      { name: "Abu-abu", hex: "#708090" },
      { name: "Krem", hex: "#F5F5DC" }
    ],
    materials: ["Kayu Premium", "Rangka Aluminium"]
  }
};

const ProductDetailPage = () => {
  const { id } = useParams();
  const product = productData[id] || productData[1];
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  
  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
  };
  
  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
  };
  
  return (
    <>
      <Helmet>
        <title>{`${product.name} - NEXTMODE`}</title>
        <meta name="description" content={product.description} />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1">
          <section className="py-12 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <Link
                  to="/products"
                  className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Kembali ke Produk
                </Link>
              </motion.div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                >
                  <div className="relative">
                    <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-muted">
                      <AnimatePresence mode="wait">
                        <motion.img
                          key={currentImageIndex}
                          src={product.images[currentImageIndex]}
                          alt={`${product.name} tampilan ${currentImageIndex + 1}`}
                          className={`w-full h-full object-cover ${isZoomed ? 'cursor-zoom-out' : 'cursor-zoom-in'}`}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1, scale: isZoomed ? 1.5 : 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          onClick={() => setIsZoomed(!isZoomed)}
                        />
                      </AnimatePresence>
                      
                      {!isZoomed && (
                        <>
                          <button
                            onClick={prevImage}
                            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-background transition-all duration-200"
                            aria-label="Gambar sebelumnya"
                          >
                            <ChevronLeft className="w-5 h-5" />
                          </button>
                          
                          <button
                            onClick={nextImage}
                            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-background transition-all duration-200"
                            aria-label="Gambar selanjutnya"
                          >
                            <ChevronRight className="w-5 h-5" />
                          </button>
                          
                          <div className="absolute bottom-4 right-4">
                            <button
                              onClick={() => setIsZoomed(true)}
                              className="w-10 h-10 bg-background/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-background transition-all duration-200"
                              aria-label="Perbesar gambar"
                            >
                              <ZoomIn className="w-5 h-5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                    
                    <div className="flex gap-3 mt-4">
                      {product.images.map((image, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-all duration-200 ${
                            index === currentImageIndex
                              ? 'border-primary ring-2 ring-primary ring-offset-2'
                              : 'border-border hover:border-primary/50'
                          }`}
                        >
                          <img
                            src={image}
                            alt={`${product.name} thumbnail ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="flex flex-col"
                >
                  <Badge className="w-fit mb-4 bg-secondary text-secondary-foreground">
                    {product.category}
                  </Badge>
                  
                  <h1 className="text-4xl font-bold mb-4">{product.name}</h1>
                  
                  <p className="text-2xl font-semibold text-primary mb-6 font-variant-numeric-tabular">
                    {product.price}
                  </p>
                  
                  <p className="text-muted-foreground leading-relaxed mb-8">
                    {product.description}
                  </p>
                  
                  <div className="bg-muted p-6 rounded-xl mb-8">
                    <h2 className="text-lg font-semibold mb-4">Spesifikasi</h2>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Dimensi</p>
                        <p className="font-medium">{product.specs.dimensions}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Berat</p>
                        <p className="font-medium">{product.specs.weight}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Material</p>
                        <p className="font-medium">{product.specs.material}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Waktu Pemasangan</p>
                        <p className="font-medium">{product.specs.setup}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mb-8">
                    <h2 className="text-lg font-semibold mb-4">Pilihan Warna</h2>
                    <div className="flex gap-3">
                      {product.colors.map((color, index) => (
                        <div key={index} className="flex flex-col items-center gap-2">
                          <div
                            className="w-12 h-12 rounded-xl border-2 border-border"
                            style={{ backgroundColor: color.hex }}
                          />
                          <span className="text-sm text-muted-foreground">{color.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-8">
                    <h2 className="text-lg font-semibold mb-4">Pilihan Material</h2>
                    <div className="flex flex-wrap gap-2">
                      {product.materials.map((material, index) => (
                        <Badge key={index} variant="outline">
                          {material}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mt-auto">
                    <Link to="/custom-order">
                      <Button size="lg" className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90">
                        Pesan Custom Booth Ini
                        <ArrowRight className="ml-2 w-5 h-5" />
                      </Button>
                    </Link>
                  </div>
                </motion.div>
              </div>
            </div>
          </section>
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default ProductDetailPage;
