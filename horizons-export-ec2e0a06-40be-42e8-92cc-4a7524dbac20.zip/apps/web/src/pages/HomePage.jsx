
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Palette, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ProductCarousel from '@/components/ProductCarousel.jsx';

const products = [
  {
    id: 1,
    name: "DAPOER KLEON",
    category: "Makanan",
    image: "https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/c31607222d5885814fc9ddb527ad6d3a.jpg",
    description: "Booth makanan kompak dengan desain modern dan setup peralatan lengkap",
    price: "Mulai dari Rp 15.000.000"
  },
  {
    id: 2,
    name: "Sweets Bites",
    category: "Makanan Ringan",
    image: "https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/7010411256ad62c81d6224cf181a7a27.jpg",
    description: "Booth serbaguna dengan rak yang dapat disesuaikan dan opsi tampilan menarik",
    price: "Mulai dari Rp 12.500.000"
  },
  {
    id: 3,
    name: "Naura Sunrise",
    category: "Minuman",
    image: "https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/c776d9015f933964b856d7b1ddb6de2c.jpg",
    description: "Kios minuman segar dengan pendingin dan meja persiapan",
    price: "Mulai dari Rp 18.000.000"
  }
];

const features = [
  {
    icon: Zap,
    title: "Pengiriman Cepat",
    description: "Produksi dan pengiriman cepat agar bisnis Anda segera berjalan"
  },
  {
    icon: Palette,
    title: "Kustomisasi Penuh",
    description: "Pilih warna, material, dan tata letak yang sesuai dengan merek Anda"
  },
  {
    icon: Shield,
    title: "Tahan Lama",
    description: "Material tahan cuaca dan konstruksi yang diperkuat untuk penggunaan bertahun-tahun"
  }
];

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>NEXTMODE - Booth Portable yang Dapat Dikustomisasi</title>
        <meta name="description" content="Desain dan pesan booth portable kustom untuk bisnis makanan, minuman, dan ritel. Pengiriman cepat, dapat dikustomisasi penuh, dan tahan lama." />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1">
          <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/5">
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none mix-blend-soft-light">
              <img
                src="https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/7b04bfec5f84cc04be09609bf2d5dc88.jpg"
                alt=""
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <img 
                    src="https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/7b04bfec5f84cc04be09609bf2d5dc88.jpg" 
                    alt="NEXTMODE Logo" 
                    className="h-16 w-auto object-contain rounded-md mb-8 shadow-sm"
                  />
                  <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                    Booth Portable yang Dapat Dikustomisasi
                  </h1>
                  <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8 max-w-prose">
                    Dari kios kopi hingga stan ritel, kami membangun solusi mobile yang beradaptasi dengan kebutuhan Anda. Pilih desain Anda, tentukan material, dan mulai berjualan dalam beberapa minggu.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Link to="/products">
                      <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 w-full sm:w-auto">
                        Jelajahi Produk
                        <ArrowRight className="ml-2 w-5 h-5" />
                      </Button>
                    </Link>
                    <Link to="/custom-order">
                      <Button size="lg" variant="outline" className="w-full sm:w-auto">
                        Mulai Sekarang
                      </Button>
                    </Link>
                  </div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="relative"
                >
                  <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                    <img
                      src="https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/c31607222d5885814fc9ddb527ad6d3a.jpg"
                      alt="NEXTMODE custom portable booth showcase"
                      className="w-full h-auto"
                    />
                  </div>
                </motion.div>
              </div>
            </div>
          </section>
          
          <section className="py-20 bg-muted">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Mengapa Memilih NEXTMODE</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Kami menggabungkan pengerjaan berkualitas dengan desain fleksibel untuk menciptakan booth yang bekerja untuk Anda
                </p>
              </motion.div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-card p-8 rounded-2xl"
                  >
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                      <feature.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
          
          <section className="py-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Produk Unggulan</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Jelajahi desain booth kami yang paling populer, siap untuk dikustomisasi
                </p>
              </motion.div>
              
              <ProductCarousel products={products} />
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center mt-12"
              >
                <Link to="/products">
                  <Button size="lg" variant="outline">
                    Lihat Semua Produk
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
              </motion.div>
            </div>
          </section>
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default HomePage;
