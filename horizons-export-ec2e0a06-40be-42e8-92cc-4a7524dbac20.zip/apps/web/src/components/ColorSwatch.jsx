
import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

const ColorSwatch = ({ color, name, selected, onClick }) => {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      className="relative flex flex-col items-center gap-2 group"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      transition={{ duration: 0.2 }}
    >
      <div
        className={`w-16 h-16 rounded-xl border-2 transition-all duration-200 ${
          selected
            ? 'border-primary ring-2 ring-primary ring-offset-2'
            : 'border-border hover:border-primary/50'
        }`}
        style={{ backgroundColor: color }}
      >
        {selected && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="w-full h-full flex items-center justify-center"
          >
            <Check className="w-6 h-6 text-white drop-shadow-lg" strokeWidth={3} />
          </motion.div>
        )}
      </div>
      <span className="text-sm font-medium text-foreground">{name}</span>
    </motion.button>
  );
};

export default ColorSwatch;
