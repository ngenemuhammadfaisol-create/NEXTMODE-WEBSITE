
import React from 'react';
import { motion } from 'framer-motion';

const sizes = [
  { id: 'small', label: 'Kecil', dimensions: '2m x 1.5m', price: '+Rp 0' },
  { id: 'medium', label: 'Sedang', dimensions: '3m x 2m', price: '+Rp 12.000.000' },
  { id: 'large', label: 'Besar', dimensions: '4m x 2.5m', price: '+Rp 24.000.000' }
];

const SizeSelector = ({ selected, onChange }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {sizes.map((size) => (
        <motion.button
          key={size.id}
          type="button"
          onClick={() => onChange(size.id)}
          className={`p-6 rounded-xl border-2 transition-all duration-200 text-left ${
            selected === size.id
              ? 'border-primary bg-primary/5 ring-2 ring-primary ring-offset-2'
              : 'border-border hover:border-primary/50 bg-card'
          }`}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex flex-col gap-2">
            <span className="text-lg font-semibold text-foreground">{size.label}</span>
            <span className="text-sm text-muted-foreground">{size.dimensions}</span>
            <span className="text-sm font-medium text-secondary">{size.price}</span>
          </div>
        </motion.button>
      ))}
    </div>
  );
};

export default SizeSelector;
