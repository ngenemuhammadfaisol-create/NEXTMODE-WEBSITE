
import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

const materials = [
  { id: 'wood', name: 'Kayu Premium', description: 'Plywood marine-grade dengan pelapis tahan cuaca', price: '+Rp 0' },
  { id: 'metal', name: 'Rangka Aluminium', description: 'Ringan dan tahan karat', price: '+Rp 6.000.000' },
  { id: 'fabric', name: 'Panel Kanvas', description: 'Kain outdoor tahan lama dengan perlindungan UV', price: '+Rp 3.000.000' }
];

const MaterialSelector = ({ selected, onChange }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {materials.map((material) => (
        <motion.button
          key={material.id}
          type="button"
          onClick={() => onChange(material.id)}
          className={`p-6 rounded-xl border-2 transition-all duration-200 text-left relative ${
            selected === material.id
              ? 'border-primary bg-primary/5 ring-2 ring-primary ring-offset-2'
              : 'border-border hover:border-primary/50 bg-card'
          }`}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          {selected === material.id && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute top-4 right-4"
            >
              <Check className="w-5 h-5 text-primary" strokeWidth={3} />
            </motion.div>
          )}
          <div className="flex flex-col gap-2">
            <span className="text-lg font-semibold text-foreground">{material.name}</span>
            <span className="text-sm text-muted-foreground">{material.description}</span>
            <span className="text-sm font-medium text-secondary">{material.price}</span>
          </div>
        </motion.button>
      ))}
    </div>
  );
};

export default MaterialSelector;
