
import React from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, Instagram, Facebook, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <img 
              src="https://horizons-cdn.hostinger.com/ec2e0a06-40be-42e8-92cc-4a7524dbac20/7b04bfec5f84cc04be09609bf2d5dc88.jpg" 
              alt="NEXTMODE Logo" 
              className="h-12 w-auto object-contain rounded-md bg-white p-1 mb-4"
            />
            <p className="mt-4 text-primary-foreground/80 leading-relaxed max-w-md">
              Booth portable kustom yang dirancang untuk bisnis Anda. Dari kios makanan hingga stan ritel, kami membangun solusi yang bergerak bersama Anda.
            </p>
          </div>
          
          <div>
            <span className="font-semibold text-lg">Tautan Cepat</span>
            <div className="mt-4 flex flex-col gap-3">
              <Link to="/" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                Beranda
              </Link>
              <Link to="/products" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                Produk
              </Link>
              <Link to="/about" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                Tentang Kami
              </Link>
              <Link to="/contact" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                Kontak
              </Link>
            </div>
          </div>
          
          <div>
            <span className="font-semibold text-lg">Hubungi Kami</span>
            <div className="mt-4 flex flex-col gap-3">
              <a
                href="https://wa.me/6289632611030"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
                <span>089632611030</span>
              </a>
              <a
                href="mailto:info@nextmode.com"
                className="flex items-center gap-2 text-primary-foreground/80 hover:text-primary-foreground transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span>info@nextmode.com</span>
              </a>
            </div>
            
            <div className="mt-6 flex gap-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary-foreground/80 hover:text-primary-foreground transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary-foreground/80 hover:text-primary-foreground transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-primary-foreground/20 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-primary-foreground/60">
            © 2026 NEXTMODE. Hak Cipta Dilindungi.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-primary-foreground/60 hover:text-primary-foreground transition-colors">
              Kebijakan Privasi
            </a>
            <a href="#" className="text-primary-foreground/60 hover:text-primary-foreground transition-colors">
              Syarat & Ketentuan
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
